<?php include 'includes-pages/header.php' ?>
<?php include 'includes-pages/menu-navigation.php' ?>

<div class="cafe-list-container">
    <div class="dishes-header">
        <h2 class="dishes-header-title">
            Salads<span class="dish-header-sub-t">(Good for 2-3 persons)</span>
        </h2>
    </div>
    <div class="cafe-item-menu row">
        <!-- ARDCI Chef Salad card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">ARDCI Chef Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p class="ardci-salad-p">
                        Lettuce mixed with boiled egg, onions, bell peper and balsamic vinegar.
                        </p>
                        <span class="in-prices">Price: &#8369;230.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='ARDCI-Chef-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>

        <!-- Mango Chicken Salad card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container mccc-right flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">Mango<br>Chicken Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p>
                        Fresh mango strips, lettuce, mayonnaise, drizzled with honey and lemon.
                        </p>
                        <span class="in-prices">Price: &#8369;235.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='Mango-Chicken-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>

        <!-- Caesar Salad card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">Caesar Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p class="ceasar-salad-p">
                        Lettuce with croutons dressed with olive oil, lemon juice and balsamic vinegar.
                        </p>
                        <span class="in-prices">Price: &#8369;280.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='Ceasar-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>

        <!-- Hawaiian Potato Salad card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container mccc-right flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">Hawaiian Potato Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p class="">
                        Boiled cubed potatoes and pineapple slices in creamy salad sauce.
                        </p>
                        <span class="in-prices">Price: &#8369;450.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='Hawaiian-Potato-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>
        <!-- Creamy Carrot Salad card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">Creamy Carrot Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p class="ceasar-salad-p">
                            Shredded carrots with velvet and creamy dressing.
                        </p>
                        <span class="in-prices">Price: &#8369;170.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='Creamy-Carrot-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>

        <!-- Macaroni card -->
        <a role="button" class="cards-anchor col-6">
            <div class="menu-categories-card-container flex-grow-1">
                <div class="mcc-ing-preview">
                    <div class="mcc-tilte-head">
                        <h1 class="mcc-title">Macaroni Salad</h1>
                    </div>
                    <div class="mcc-ing">
                        <p class="ceasar-salad-p">
                            Tender macaroni pasta in a smooth, creamy house dressing. A sweet, savory, and timeless favorite.
                        </p>
                        <span class="in-prices">Price: &#8369;275.00</span>
                    </div>
                    <div class="add-list-con"><button class="add-list-btn" data-name='Creamy-Carrot-Salad' onclick="saladArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                </div>
            </div>
        </a>
    </div>
</div>


<?php include 'includes-pages/footer.php'?>